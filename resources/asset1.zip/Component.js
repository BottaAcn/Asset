sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("asset1.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map